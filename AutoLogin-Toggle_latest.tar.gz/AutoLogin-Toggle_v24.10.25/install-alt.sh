#!/bin/bash
#
# AutoLogin-Toggle
# Created: 2024-10-18 
#
# A lot of people including myself are looking for a simple solution for enabling or disabling autologin for Linux,
# particularly for the XFCE desktop environment using the LightDM login interface.
# Necessity is the mother of invention. So here it is. 
#
# This script will add the AutoLogin Toggle icon to your System Manager, and necessary associated files to your computer..
#
# Enjoy! 
# -Joseph
#
# olddognewlinux@gmail.com
#
sudo cp -f files/autologin-toggle.desktop /usr/share/applications
sudo cp -f files/autologin-toggle.sh /usr/bin
sudo cp -f files/login.svg /usr/share/icons
sudo cp -n files/lightdm.conf /etc/lightdm
sudo chmod ugo+rw /usr/share/applications/autologin-toggle.desktop
sudo chmod ugo+rwx /usr/bin/autologin-toggle.sh
sudo chmod ugo+rw /usr/share/icons/login.svg
kill -9 $PPID
#
# If needed, use this command to make the file executable:  chmod +x install-alt.sh
# Or, right-click-->properties-->permissions-->check 'Execute' box.
#
