#!/bin/bash
#
# autologin-toggle uninstall
# Created: 2024-10-18
#
# This will remove the AutoLogin Toggle icon from your System Manager, and associated files from your computer.
#
# olddognewlinux@gmail.com
#
sudo sed -i 's/autologin-user='$USER'/#autologin-user=/' /etc/lightdm/lightdm.conf
sudo rm /usr/share/applications/autologin-toggle.desktop 
sudo rm /usr/bin/autologin-toggle.sh
sudo rm /usr/share/icons/login.svg
#
